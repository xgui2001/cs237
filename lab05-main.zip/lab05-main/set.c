#include "set.h"

/*
 * Returns a pointer to a dynamically allocated set with the specified
 * number of blocks allocated and initialized.
 */
struct set *initializeSet(int associativity)
{
  // dynamically allocates space for the set
  struct set *ourSet = (struct set *)malloc(sizeof(struct set));

  // dynamically allocates space for the blocks
  ourSet->blocks = (struct block *)
      malloc(associativity * sizeof(struct block));

  // sets the associativity value of the set to the value we passed in
  ourSet->associativity = associativity;

  // set the validity bit for each block within ourset
  for (int i = 0; i < associativity; i++)
  {
    ourSet->blocks[i].vFlag = 0;
  }

  return ourSet;
}

/*
 * Frees all memory dynamically allocated to store set data structure
 */
void freeSet(struct set *set)
{
  free(set->blocks);
  free(set);
}

/*
 * Adds the access of specified tag to the set.  Returns 1 if
 * was a hit.  Returns 0 if a miss with no eviction, -1 if a
 * miss that caused an eviction.
 */
int addSetAccess(struct set *s, unsigned long long int tag)
{

  // make sure set is not null (if s is a null, it is a miss)
  if (s == NULL)
  {
    return 0;
  }
  // parsing over every block of the set
  for (int i = 0; i < s->associativity; i++)
  {
    // case: hit; the tag matches and it is a valid block
    if (s->blocks[i].vFlag == 1 && tag == s->blocks[i].tag)
    {
      // finds the lru of the current block
      int currentLRU = s->blocks[i].lruFlag;

      // adjusting the lru of other blocks in the set
      lruAdjust(currentLRU, s);

      // set current block's lru to 0
      s->blocks[i].lruFlag = 0;
      return 1;
    }
  }
  // integer to store the index of the block with the highest lru
  int highestLRUIndex = 0;

  // parsing over every block of the set
  for (int k = 0; k < s->associativity; k++)
  {
    // track block with highest lru
    if (s->blocks[k].lruFlag > s->blocks[highestLRUIndex].lruFlag)
    {
      // if we found a block with higher lru than the tracked highest
      // store the block's index
      highestLRUIndex = k;
    }
    // miss with no eviction: there exists an empty block
    if (s->blocks[k].vFlag == 0)
    {
      // update the empty block to be the block that is most recently used
      s->blocks[k].tag = tag;
      s->blocks[k].vFlag = 1;

      // adjust lru of other blocks with respect to the used block
      lruAdjust(s->associativity, s);

      // set the current block lru to be 0
      s->blocks[k].lruFlag = 0;
      return 0;
    }
  }
  // if the for loop doesn't hit or miss without eviction
  // it must be a miss with eviction
  // overwrite tag of block with highest lru
  s->blocks[highestLRUIndex].tag = tag;

  // adjust every block's lrus within the set
  lruAdjust(s->associativity - 1, s);

  // set the current block's lru to 0
  s->blocks[highestLRUIndex].lruFlag = 0;

  return -1;
}

/*
 * helper function that takes in a set and a LRU,
 * increments the lru of other blocks with a lower lru
 * than the current one.
 */
void lruAdjust(int currentLRU, struct set *s)
{
  for (int j = 0; j < s->associativity; j++)
  {
    if (s->blocks[j].lruFlag <= currentLRU)
    {
      s->blocks[j].lruFlag++;
    }
  }
}
