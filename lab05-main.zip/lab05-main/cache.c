#include "cache.h"

/*
 * Returns a pointer to a dynamically allocated cache with the specified
 * associativity and using the number of specified set index bits and block
 * offset bits.
 */
 struct cache *initializeCache(int setIndexBits, int associativity, 
  int blockOffsetBits)
{
  // dynamically allocate space in memory for ourCache
  struct cache *ourCache = (struct cache *)malloc(sizeof(struct cache));

  // initialize indexBits to be the value passed in by setIndexBits
  ourCache->indexBits = setIndexBits;

  // initialize blockOffsetBits to be the value passed in by blockOffsetBits
  ourCache->blockOffsetBits = blockOffsetBits;

  // calculate the amount of sets within the cache
  ourCache->numSets = 1 << setIndexBits;

  // dynamically allocate space in memory for each set in ourCache
  ourCache->sets = (struct set **)malloc(sizeof(struct set *) * 
    ourCache->numSets);

  for (int i = 0; i <= ourCache->numSets; i++)
  {
    // populate each set within the cache
    ourCache->sets[i] = initializeSet(associativity);
  }
  return ourCache;
}

/*
 * Frees all memory dynamically allocated to store cache data structure
 */
void freeCache(struct cache *cache)
{
  for (int i = 0; i <= cache->numSets; i++)
  {
    freeSet(cache->sets[i]);
  }
  free(cache);
}

/*
 * Adds the access of specified address to the cache.
 */
void addCacheAccess(struct cache *cache, unsigned long long int address)
{
  // calculate tag based on address
  unsigned long long int ourTag = address >> (cache->indexBits + 
    cache->blockOffsetBits);

  // calculate set index based on address
  int ourSetIndex = (address >> (cache->blockOffsetBits)) ^ 
    (ourTag << cache->indexBits);

  // adds the access of the set of the specified address
  // and stores the return information in an int
  int addSetAccessResults = addSetAccess(cache->sets[ourSetIndex], ourTag);

  if (addSetAccessResults > 0)
  {
    // increment hit count if addSetAccess returns 1
    cache->hit_count++;
  }
  if (addSetAccessResults == 0)
  {
    // increment miss count if addSetAccess returns 0
    cache->miss_count++;
  }
  if (addSetAccessResults < 0)
  {
    // increment eviction and miss count if addSetAccess returns 1
    cache->miss_count++;
    cache->eviction_count++;
  }
}
