#include "cachelab.h"
#include "cache.h"

#include <getopt.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_FILENAME_LENGTH 80  // max length of file name
#define MAX_FILE_LINE_LENGTH 80 // max length of line in file

// main method to run our cache simulator
// that simulates the behavior of a cache memory from a memory trace
// and outputs the total number of hits, misses, and evictions
int main(int argc, char **argv)
{
      // value to store current command line argument being parsed
      int c;

      // values that will track command line arguments
      int numIndexBits = 0;
      int associativity = 0;
      int numBlockBits = 0;
      char nameOfFile[MAX_FILENAME_LENGTH];

      // take and store command line arguments that specify size of the cache
      while ((c = getopt(argc, argv, "hvs:E:b:t:")) != -1)
      {
            switch (c)
            {
            case 'h':
                  // help flag, print info related to usage
                  break;
            case 'v':
                  // verbose flag, print info related to trace info
                  break;
            case 's':
                  // stores the number of index bits
                  numIndexBits = atoi(optarg);
                  break;
            case 'E':
                  // stores the number representing set associativity
                  associativity = atoi(optarg);
                  break;
            case 'b':
                  // stores the number of block offset bits
                  numBlockBits = atoi(optarg);
                  break;
            case 't':
                  // stores the name of the trace file
                  strcpy(nameOfFile, optarg);
                  break;
            }
      }

      // initialize the cache
      struct cache *ourCache = initializeCache(numIndexBits, 
            associativity, numBlockBits);

      // initialize the file object
      FILE *fp;

      // array to store a line in the file
      char strLine[MAX_FILE_LINE_LENGTH];

      // check for error
      fp = fopen(nameOfFile, "r");
      if (fp == NULL)
      {
            perror("Error opening file");
      }

      // reads in each line and stores it
      while (fgets(strLine, MAX_FILE_LINE_LENGTH, fp) != NULL)
      {
            // char to store the operation field
            char opField;    

            // int to store the address      
            unsigned long long int currentAddress; 

            // int to store the size
            int currentSize;                      

            // read in formatted line
            sscanf(strLine, " %c %llx,%d", &opField, 
                  &currentAddress, &currentSize);

            // skip over instruction loads
            if (opField == 'I')
            {
                  continue;
            }
            // adds the access of the current address to the cache
            addCacheAccess(ourCache, currentAddress);

            // call cddCacheAccess for an additional time
            // if it is a data modify operation
            if (opField == 'M')
            {
                  addCacheAccess(ourCache, currentAddress);
            }
      }
      fclose(fp);

      // print the total counts of hit, miss, evictions of the simulated cache
      printSummary(ourCache->hit_count, ourCache->miss_count, 
            ourCache->eviction_count);

      // free all the dynamically allocated memory for ourCache
      freeCache(ourCache);

      return 0;
}
