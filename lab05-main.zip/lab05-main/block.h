#ifndef _BLOCK_H_
#define _BLOCK_H_

/*
 * Represents a memory system cache block.  Stores the meta data
 * used to identify each unique block and its current state.
 */
struct block
{
  int vFlag;                  // stores the validity of each block
  unsigned long long int tag; // tag of each block
  int lruFlag;                // stores the LRU of each block
};

#endif
