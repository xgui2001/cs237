# CS237 Lab 1 Feedback
Total score: 40/40.5

## `Unix environment` Feedback
### Total points for Unix environment: 3/3

## `C-practice` Feedback
### README.md:  0.5/0.5
### loop_sum: 2/2
### Style points: 1/1
### is_palindrome: 3/3
### Style points: 1/1
## `gdb-practice` Feedback
### Total points for gdb-practice: 3/3

## `bit-puzzle` Feedback
```
Correctness Results	Perf Results
Points	Rating	Errors	Points	Ops	Puzzle
1	1	0	2	4	bitwise_and
1	1	0	2	4	set_third_bits
2	2	0	2	9	is_any_even_bit_set
2	2	0	2	2	is_equal
3	3	0	2	7	replace_byte
4	4	0	2	11	bitwise_parity

Score = 25/25 [13/13 Corr + 12/12 Perf] (37 total operators)


Correctness: 		    13 / 13

Performance: 		    12 / 12

Coding Style:		    1.5 / 2

             		____________

Combined score: 	  26.5 / 27

Comments:  Nice job!  Use descriptive variable names and remember to include
white space between functions.
```
