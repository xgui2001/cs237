#include <stdio.h>
#include <stdlib.h>
#include "isa.h"
#include "registers.h"
#include "parser.h"
#include "sim.h"
#include "instruction.h"

// Prints usage information
void printUsage()
{
  printf("Usage: sim <tracefile> <# instructions>\n");
}

// Given a Y86-64 tracefile and the number of instructions to simulate in
// the trace file, simulates executing those instructions on an ideal
// pipeline, a stalling pipeline, and a data forwarding pipeline and prints
// out the completion times of those instructions on each pipeline.
int main(int argc, char *argv[])
{
  if (argc < 3)
  {
    printUsage();
    exit(EXIT_FAILURE);
  }

  // Make sure the number of instructions specified is a positive integer
  int numInstrs = atoi(argv[2]);
  if (numInstrs < 1)
  {
    printUsage();
    exit(EXIT_FAILURE);
  }

  // Get the set of instructions from the trace file
  Instruction *instrs = readInstructions(argv[1], numInstrs);

  // Execute and print the results of the ideal pipeline
  InstructionCompletion *noHazardTimes = executeNoHazardPipeline(instrs,
                                                                 numInstrs);
  printCompletionTimes("No hazards", noHazardTimes, numInstrs);
  free(noHazardTimes);

  // Execute and print the results of the stalling pipeline
  InstructionCompletion *stallTimes = executeStallPipeline(instrs,
                                                           numInstrs);
  printCompletionTimes("\nStall on hazards", stallTimes, numInstrs);
  free(stallTimes);

  // Execute and print the results of the data forwarding  pipeline
  InstructionCompletion *forwardTimes = executeForwardPipeline(instrs,
                                                               numInstrs);
  printCompletionTimes("\nForward on hazards", forwardTimes, numInstrs);
  free(forwardTimes);

  // Need to free instructions
  freeInstructions(instrs, numInstrs);
}

// Given an array of instructions, execute the specified number of
// instructions on the pipeline and return an array of InstructionCompletion
// instances, one for each of the numInstrs that indicates the instruction's
// completion time.  This pipeline is ideal in that no instructions stall.
InstructionCompletion *executeNoHazardPipeline(Instruction *instrs,
                                               int numInstrs)
{
  // Create completion time array
  InstructionCompletion *completeTimes =
      (InstructionCompletion *)malloc(numInstrs * sizeof(InstructionCompletion));

  // Initialize an empty pipeline of NUM_STAGES.  Each pipeline stage
  // stores a pointer to the Instruction in that stage or NULL if no
  // instruction is currently in that stage.
  Instruction *pipeline[NUM_STAGES];
  for (int i = 0; i < NUM_STAGES; i++)
  {
    pipeline[i] = NULL;
  }

  // Simulate the pipeline
  int time = 0;
  int completedCount = 0;
  int enteredCount = 0;

  // While not all instructions have completed execution
  while (enteredCount < numInstrs || !isPipelineEmpty(pipeline))
  {

    // Move instructions already in the pipeline one stage forward starting at
    // end of pipeline and moving forward to first pipeline stage
    for (int i = NUM_STAGES - 1; i >= 0; i--)
    {
      if (pipeline[i] != NULL)
      {
        // If the pipeline stage is not empty

        if (i == PIPE_WRITE_REG_STAGE)
        {
          // If the pipeline stage is the last stage where we write to
          // registers, create an InstructionCompletion entry for the
          // instruction
          completeTimes[completedCount].instr = pipeline[i];
          completeTimes[completedCount].completionTime = time;
          completedCount++;
          pipeline[i] = NULL;
        }
        else
        {
          // If the pipeline stage is not the last stage, just advance
          // the instruction one stage.  Since we don't recognize hazards
          // and consequently don't stall instructions, there is no reason
          // to check if the next pipeline stage is unoccupied before
          // advancing.
          pipeline[i + 1] = pipeline[i];
          pipeline[i] = NULL;
        }
      }
    }

    if (enteredCount < numInstrs)
    {
      // This handles the insertion of instructions into the first
      // stage of the pipeline.  If there are instructions that
      // haven't entered the pipeline yet, insert the next instruction
      // into the pipeline's first stage.
      pipeline[PIPE_ENTER_STAGE] = &instrs[enteredCount];
      enteredCount++;
    }

    // Advance time
    time++;
  }

  // Return the array of InstructionCompletion instances
  return completeTimes;
}

// Given an array of instructions, execute the specified number of
// instructions on the pipeline and return an array of InstructionCompletion
// instances, one for each of the numInstrs that indicates the instruction's
// completion time.  This pipeline stalls instructions waiting for their
// source operand registers to be written by an instruction already in the
// pipeline until that instruction has been to the register file.  It also
// stalls on control instructions until the target destination is know.
InstructionCompletion *executeStallPipeline(Instruction *instrs,
                                            int numInstrs)
{
  // Create completion time array
  InstructionCompletion *completeTimes =
      (InstructionCompletion *)malloc(numInstrs * sizeof(InstructionCompletion));

  // Initialize an empty pipeline of NUM_STAGES.  Each pipeline stage
  // stores a pointer to the Instruction in that stage or NULL if no
  // instruction is currently in that stage.
  Instruction *pipeline[NUM_STAGES];
  for (int i = 0; i < NUM_STAGES; i++)
  {
    pipeline[i] = NULL;
  }

  // Simulate the pipeline
  int time = 0;
  int completedCount = 0;
  int enteredCount = 0;

  // While not all instructions have completed execution
  while (enteredCount < numInstrs || !isPipelineEmpty(pipeline))
  {

    // Move instructions already in the pipeline one stage forward starting at
    // end of pipeline and moving forward to first pipeline stage.
    // If there exists RAW dependencies or Control Hazard, instruction(s) will
    // be stalled.
    for (int i = NUM_STAGES - 1; i >= 0; i--)
    {
      if (pipeline[i] != NULL)
      {
        // If the stage is not empty.

        if (i == PIPE_WRITE_REG_STAGE)
        {
          // If the pipeline stage is the last stage where we write to
          // registers, create an InstructionCompletion entry for the
          // instruction
          completeTimes[completedCount].instr = pipeline[i];
          completeTimes[completedCount].completionTime = time;
          completedCount++;
          pipeline[i] = NULL;
        }
        else if (i == PIPE_READ_REG_STAGE)
        {
          // If the pipeline stage is the Read stage,
          // check for RAW Dependencies.
          // Move instruction to the next stage of the pipeline if:
          // 1) the next stage is empty, and
          // 2) nothing in the pipeline would have data hazard
          // with the current instruction
          if (pipeline[i + 1] == NULL && !hasRAWDependency(pipeline))
          {
            // Advance the instruction to the next stage
            pipeline[i + 1] = pipeline[i];
            pipeline[i] = NULL;
          }
        }
        else
        {
          // If the pipeline stage is not the Write Back stage or Read stage,
          // just advance the instruction one stage forward.
          if (pipeline[i + 1] == NULL)
          {
            // check if the next stage is empty, if so, move instr
            // to the next stage
            pipeline[i + 1] = pipeline[i];
            pipeline[i] = NULL;
          }
        }
      }
    }

    if (enteredCount < numInstrs &&
        pipeline[PIPE_ENTER_STAGE] == NULL && !hasControlHazard(pipeline))
    {
      // This handles the insertion of instructions into the first
      // stage of the pipeline.  If there are instructions that
      // haven't entered the pipeline yet, check for Control Hazard.

      // If no control hazard AND PIPE_ENTER_STAGE is empty, move the next
      // instruction into the first stage of the pipeline.
      pipeline[PIPE_ENTER_STAGE] = &instrs[enteredCount];
      enteredCount++;
    }

    // Advance time
    time++;
  }

  // Return the array of InstructionCompletion instances
  return completeTimes;
}

// Helper function that checks if the current instruction in the Read stage
// has Data Hazard with any other instruction in the pipeline in front of the
// Read stage.
// Returns 1 if there is RAW dependency, 0 otherwise.
int hasRAWDependency(Instruction *pipeline[])
{
  int curr_stage = PIPE_READ_REG_STAGE;

  // the instruction currently in the Read stage of the pipeline.
  Instruction *curr;
  curr = pipeline[curr_stage];

  // an array storing the source reg IDs of the current inst
  RegID curr_src_regs[MAX_SRC_REGS];
  int curr_src_regs_count = getSrcRegisters(curr, curr_src_regs);

  for (int i = curr_stage + 1; i < NUM_STAGES; i++)
  {
    // an instruction already in the pipeline.
    Instruction *front = pipeline[i];

    if (front != NULL)
    {
      // an array storing the dest reg IDs of the front instr
      RegID front_dest_regs[MAX_DEST_REGS];
      int front_dest_regs_count = getDestRegisters(front, front_dest_regs);

      for (int j = 0; j < curr_src_regs_count; j++)
      {
        // a src register of the current instr
        RegID src_reg = curr_src_regs[j];
        for (int k = 0; k < front_dest_regs_count; k++)
        {
          RegID dest_reg = front_dest_regs[k]; // a dest reg of the front instr

          // If src_reg is the same as dest_reg, RAW dependency exists.
          if (src_reg == dest_reg)
          {
            return 1;
          }
        }
      }
    }
  }

  // No RAW dependency between the instr in Read stage
  // and the rest of the pipeline.
  return 0;
}

// Helper function to check if there exists a control hazard in the pipeline.
// Returns 1 if there exists a control hazard, 0 otherwise.
int hasControlHazard(Instruction *pipeline[])
{
  for (int i = PIPE_ENTER_STAGE; i <= PIPE_KNOW_NEXTPC; i++)
  {
    // check if any instr up to the Execute stage is a control instruction
    Instruction *instr = pipeline[i];
    if (instr != NULL && isControlInstruction(instr->name))
    {
      // there exists a Control Hazard
      return 1;
    }
  }

  // No Control Hazard
  return 0;
}

// Given an array of instructions, execute the specified number of
// instructions on the pipeline and return an array of
// InstructionCompletion instances, one for each of the numInstrs that
// indicates the instruction's completion time.  This pipeline stalls
// instructions waiting for their source operand registers to be
// written by an instruction already in the pipeline until that
// instruction has produced the value and can forward it to the
// instruction needing it's value.  It also stalls on control
// instructions until the target destination is know.
InstructionCompletion *executeForwardPipeline(Instruction *instrs,
                                              int numInstrs)
{
  // Create completion time array
  InstructionCompletion *completeTimes =
      (InstructionCompletion *)malloc(numInstrs * sizeof(InstructionCompletion));

  // Initialize an empty pipeline of NUM_STAGES.  Each pipeline stage
  // stores a pointer to the Instruction in that stage or NULL if no
  // instruction is currently in that stage.
  Instruction *pipeline[NUM_STAGES];
  for (int i = 0; i < NUM_STAGES; i++)
  {
    pipeline[i] = NULL;
  }

  // Simulate the pipeline
  int time = 0;
  int completedCount = 0;
  int enteredCount = 0;

  // While not all instructions have completed execution
  while (enteredCount < numInstrs || !isPipelineEmpty(pipeline))
  {

    // Move instructions already in the pipeline one stage forward starting at
    // end of pipeline and moving forward to first pipeline stage.
    // For the instruction at PIPE_READ_FORWARD_REG_STAGE, we need to check
    // if there exists RAW dependencies with instructions already
    // in the pipeline. If there are RAW dependencies,
    // stall the instr at PIPE_READ_FORWARD_REG_STAGE
    // if data forwarding cannot be done,
    // move this instr forward if data forwarding can be done.
    for (int i = NUM_STAGES - 1; i >= 0; i--)
    {
      if (pipeline[i] != NULL)
      {
        // If the stage is not empty.

        if (i == PIPE_WRITE_REG_STAGE)
        {
          // If the pipeline stage is the last stage where we write to
          // registers, create an InstructionCompletion entry for the
          // instruction
          completeTimes[completedCount].instr = pipeline[i];
          completeTimes[completedCount].completionTime = time;
          completedCount++;
          pipeline[i] = NULL;
        }
        else if (i == PIPE_READ_FORWARD_REG_STAGE)
        {
          if (!dataForwardCheck(pipeline))
          {
            // If RAW dependency exists but cannot use data forwarding
            // to resolve the conflict, advance the instr to the next stage.
            pipeline[i + 1] = pipeline[i];
            pipeline[i] = NULL;
          }
        }
        else
        {
          // If the pipeline stage is not the Write Back stage or
          // PIPE_READ_FORWARD_REG_STAGE, just advance the instr
          // one stage forward.
          if (pipeline[i + 1] == NULL)
          {
            // check if the next stage is empty, if so, move instr
            // to the next stage
            pipeline[i + 1] = pipeline[i];
            pipeline[i] = NULL;
          }
        }
      }
    }

    if (enteredCount < numInstrs &&
        pipeline[PIPE_ENTER_STAGE] == NULL && !hasControlHazard(pipeline))
    {
      // This handles the insertion of instructions into the first
      // stage of the pipeline.  If there are instructions that
      // haven't entered the pipeline yet, check for Control Hazard.

      // If no control hazard AND PIPE_ENTER_STAGE is empty, move the next
      // instruction into the first stage of the pipeline.
      pipeline[PIPE_ENTER_STAGE] = &instrs[enteredCount];
      enteredCount++;
    }

    // Advance time
    time++;
  }

  // Return the array of InstructionCompletion instances
  return completeTimes;
}

// Helper function that checks whether the instr at PIPE_READ_FORWARD_REG_STAGE
// needs to be stalled.
// Returns 1 if needs to be stalled, 0 otherwise.
// Details of implementation:
// If there is no RAW dependency between the instr at
// PIPE_READ_FORWARD_REG_STAGE and instrs already in the pipeline,
// no stalling or data forwarding needed. Return 0.
// If there exists such RAW dependency, check if the RAW dependency can be
// resolved through data forwarding. If can be resolved, return 0.
// If cannot be resolved, return 1.
int dataForwardCheck(Instruction *pipeline[])
{
  int curr_stage = PIPE_READ_FORWARD_REG_STAGE;

  // the instr currently in the PIPE_READ_FORWARD_REG_STAGE of the pipeline.
  Instruction *curr;
  curr = pipeline[curr_stage];

  // an array storing the source reg IDs of the current instr
  RegID curr_src_regs[MAX_SRC_REGS];
  int curr_src_regs_count = getSrcRegisters(curr, curr_src_regs);

  for (int i = curr_stage + 1; i <= PIPE_MEMORY_PRODUCE_STAGE + 1; i++)
  {
    Instruction *front = pipeline[i]; // an instr already in the pipeline.

    if (front != NULL)
    {
      // an array storing the dest reg IDs of the front instr
      RegID front_dest_regs[MAX_DEST_REGS];
      int front_dest_regs_count = getDestRegisters(front, front_dest_regs);

      // Check if the curr_src_regs and front_dest_regs have overlap.
      for (int j = 0; j < curr_src_regs_count; j++)
      {
        // a src register of the current instr
        RegID src_reg = curr_src_regs[j];
        for (int k = 0; k < front_dest_regs_count; k++)
        {
          // a dest reg of the front instr
          RegID dest_reg = front_dest_regs[k];

          // If src_reg is the same as dest_reg, RAW dependency exists.
          if (src_reg == dest_reg)
          {
            // In the following,
            // the code checks if this RAW dependency
            // can be resolved through data forwarding.
            // If cannot be resolved, return 1.

            int front_src_op_count = getNumSourceOperands(front->name);

            for (int op_num = 0; op_num < front_src_op_count; op_num++)
            {
              // Loop through all source operands of the front instr.
              // Check for possiblity of using data forwarding depending on
              // whether these source operands involve Memory access.
              OperandType front_src_op_type =
                  getSourceOperandType(front->name, op_num);

              if (front_src_op_type == OP_MEMORY)
              {
                // +1 because we already moved front instr to the next stage
                if (i <= PIPE_MEMORY_PRODUCE_STAGE + 1)
                {
                  // If the front instr's source operand involves Memory access
                  // but hasn't passed the PIPE_MEMORY_PRODUCE_STAGE yet,
                  // data forwarding cannot be done. Therefore, instr at
                  // PIPE_READ_FORWARD_REG_STAGE needs to be stalled.
                  return 1;
                }
              }
              else
              {
                // +1 for the same reason as above.
                if (i <= PIPE_ALU_PRODUCE_STAGE + 1)
                {
                  // If the front instr's source operand does NOT involve
                  // Memory access but hasn't passed PIPE_ALU_PRODUCE_STAGE,
                  // data forwarding cannot be done. Therefore, instr at
                  // PIPE_READ_FORWARD_REG_STAGE needs to be stalled.
                  return 1;
                }
              }
            } // end of for loop (op_num).
          }
        }
      }
    }
  }

  // No RAW dependency, or all RAW dependencies
  // can be resolved through data forwarding.
  return 0;
}

// Returns 1 if all pipeline stages are empty.  Returns 0 otherwise.
int isPipelineEmpty(Instruction *pipeline[])
{
  for (int i = 0; i < NUM_STAGES; i++)
  {
    if (pipeline[i] != NULL)
    {
      return 0;
    }
  }
  return 1;
}

// For a specified pipeline, print out the specified number of instructions
// and their completion times to stdout
void printCompletionTimes(char *pipelineName,
                          InstructionCompletion *instrTimes, int numInstrs)
{
  if (instrTimes == NULL)
    return;

  printf("\n%s:\n", pipelineName);

  printf("Instr# \t Addr \t Instruction \t\t\t\tCompletion Time\n");
  printf("------ \t ---- \t ----------- \t\t\t\t---------------\n");
  for (int i = 0; i < numInstrs; i++)
  {
    char buffer[40];
    char *asmPtr = getInstructionAssembly(instrTimes[i].instr);
    padString(buffer, asmPtr, 40);

    printf("%d:   \t %s \t%d\n", (i + 1),
           buffer,
           instrTimes[i].completionTime);
    free(asmPtr);
  }
}
