// a simple hello world program for makefile

#include <stdio.h>

int main(int argc, char *argv[])
{
    printf("Hello World! \n");
}