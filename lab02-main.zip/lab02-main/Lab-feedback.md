# CS237 Lab 2 Feedback
Total score on this lab: 43 /47

## `C-practice` Feedback
### set.h: 1/1
### set.c: 4/4
### Makefile: 1/1
### Style points: 0.75/1
### Comments:
- Good work on Makefile.  Please see comment on clean rule
- Lines (including comments) should not exceed 80 chars.
- Comment for the set needs to explain what a set is.  "An unordered
  collection of ints with no duplicates"
- To improve readability, want to insert blank lines between distinct
  logical blocks of cde
- There are several places where logical blocks of code need to be preceded
  with comments explaining at a high level what the block of code does.

## `debugging` Feedback
### Correctness:  4/4
### Comments: 
- Good job!

## `bits.c` Feedback

```
Correctness Results	Perf Results
Points	Rating	Errors	Points	Ops	Puzzle
1	1	0	2	4	can_truncate
2	2	0	2	3	least_sig_bit
3	3	0	2	8	is_sub_ok
3	3	0	2	11	is_less_than
4	4	0	2 	21	sat_add
2	2	0	2	2	float_abs
2	4	0	1	19	float_to_int (fails on many tests)

Score = 30/33 [17/19 Corr + 13/14 Perf] (X total operators)

Correctness: 		   17 / 19

Performance: 		   13 / 14

Coding Style:		   2.25 / 3

             		__________

Total score: 		  32.25 / 36
Comments:
- dlc doesn't work properly because of variable declarations
- Need whitespace between function declarations to improve readability
- In multiple places, your comments do not provide intuition behind the
  operations you're performing and why that would give you the desired result.
  Want to provide that high level understanding of what you're doing in
  comments.
- To improve readability, want to insert blank lines between distinct
  logical blocks of code  
- Good job on horizontal spacing and naming.
- float_to_int is missing a return statement which means when e < 23,
  the code is incorrect.  Fails on many inputs.
```
