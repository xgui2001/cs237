#include "set.h"
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

// This initializes the number of elements to 0 and returns 1.
// If specified set is NULL, returns 0.
int initializeSet(struct set *s)
{
    s->num_elements = 0;
    if (s == NULL)
    {
        return 0;
    }
    return 1;
}

// If the item is already in the set or the set is full, returns 0.
// Otherwise, adds the item to the set and returns 1.
// If the specified set is NULL, returns 0.
int addItem(struct set *s, int num)
{
    if (s == NULL)
    {
        return 0;
    }

    //$ Want to insert blank lines between distinct logical blocks of code
    if (s->num_elements == MAX_ELEMENTS || containsItem(s, num) == 1)
    {
        return 0;
    }
    else
    {	    
        s->elements[s->num_elements] = num;
        s->num_elements++;
        return 1;
    }
}

// If the specified set is NULL, returns a new set that is empty.
// Otherwise, returns a new set that is a copy of the specified set.
struct set copySet(struct set *s)
{
    struct set newSet;
    initializeSet(&newSet);
    if (s == NULL)
    {
        return newSet;
    }
    else
    {
        // adding elements of set s to the new set
        for (int i = 0; i < s->num_elements; i++)
        {
            addItem(&newSet, s->elements[i]);
        }
    }
    return newSet;
}

// If the item is in the specified set, removes the item and returns 1.
// If the item is not in the specified set, returns 0.
// If the specified set is NULL, returns 0.
int removeItem(struct set *s, int item)
{
    if (s == NULL)
    {
        return 0;
    }

    //$ Want to insert blank lines between distinct logical blocks of code
    //$ Loops should be commented with a high level description of what
    //$ entire loop does.
    for (int i = 0; i < s->num_elements; i++)
    {
        // if item is found in the set
        if (s->elements[i] == item)
        {
            // remove the item by moving every element ahead one position
            for (int j = i; j < s->num_elements - 1; j++)
            {
                s->elements[j] = s->elements[j + 1];
            }
            // decrement the counter
            s->num_elements--;
            return 1;
        }
    }
    return 0;
}

// If the item is in the specified set, returns 1.
// Otherwise, returns 0. If the specified set is NULL, returns 0.
int containsItem(struct set *s, int item)
{
    if (s == NULL)
    {
        return 0;
    }

    //$ Loops should be commented with a high level description of what
    //$ entire loop does.    
    for (int i = 0; i < s->num_elements; i++)
    {
        if (s->elements[i] == item)
        {
            return 1;
        }
    }
    return 0;
}

// Returns 1 if the elements in the first set are identical
// to the elements in the second set. Otherwise, returns 0.
// If a specified set is NULL, view that as an empty set.
int areSetsEqual(struct set *a, struct set *b)
{
    // utilize the two pointer param to construct two sets
    struct set newA = copySet(a);
    struct set newB = copySet(b);

    if (newA.num_elements != newB.num_elements)
    {
        return 0;
    }

    //$ Loops should be commented with a high level description of what
    //$ entire loop does.    
    for (int i = 0; i < newA.num_elements; i++)
    {
        if (containsItem(&newB, newA.elements[i]))
        {
            continue;
        }
        else
        {
            return 0;
        }
    }
    return 1;
}

// Returns a new set that is the union of contents of the two specified sets.
// Meaning, the new set contains elements that appear in either set
// with no duplicates. If a specified set is NULL, view that as an empty set.
struct set getUnion(struct set *a, struct set *b)
{
    // if one set is null, the union of the two sets is just the other one
    if (a == NULL)
    {
        return copySet(b);
    }
    else if (b == NULL)
    {
        return copySet(a);
    }

    //$ Want to insert blank lines between distinct logical blocks of code
    // create a new set for the union
    struct set unionSet;
    initializeSet(&unionSet);
    // first add set a's elements to the union set
    unionSet = copySet(a);
    for (int i = 0; i < b->num_elements; i++)
    {
        // traverse through set b to find any elements that is not in a
        if (!containsItem(&unionSet, b->elements[i]))
        {
            // add them to union set
            addItem(&unionSet, b->elements[i]);
        }
    }
    return unionSet;
}

// Returns a new set that is the intersection of contents
// of the two specified sets. Meaning, the new set contains elements that
// appear in both sets. If a specified set is NULL, view that as an empty set.
struct set getIntersection(struct set *a, struct set *b)
{
    // create a new set for the intersection
    struct set intersectionSet;
    initializeSet(&intersectionSet);

    // if one set is null, the intersection of two sets is just the null set
    if (a == NULL || b == NULL)
    {
        return intersectionSet;
    }

    //$ Want to insert blank lines between distinct logical blocks of code
    // first add set a's elements to the intersection set
    intersectionSet = copySet(a);
    for (int i = 0; i < a->num_elements; i++)
    {
        // traverse through set a to find any elements that is not in b
        if (!containsItem(b, a->elements[i]))
        {
            // remove them from the intersection set
            removeItem(&intersectionSet, a->elements[i]);
        }
    }
    return intersectionSet;
}
