#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#define fileLength 50
#define stringLength 80

/*
 * Prints each of the num strings on its own line to stdout.
 */
void printStrings(char **strings, int num)
{
  for (int i = 0; i < num; i++)
  {
    printf("%s \n", strings[i]);
  }
  printf("\n");
}

/*
 * Frees memory for each of the num strings and frees memory for the
 * entire array.
 */
void freeStrings(char **strings, int num)
{
  for (int i = 0; i < num; i++)
  {
    free(strings[i]);
  }
  free(strings);
}

/*
 * Uses selection sort to sort the num strings in increasing order.
 */
void sortStrings(char **strings, int num)
{
  // set a variable for the new smallest string to be swapped
  char *swap;
  for (int i = 0; i < num; i++)
  {
    for (int j = i + 1; j < num; j++)
    {
      // if a smaller string is found
      if (strcmp(strings[i], strings[j]) > 0)
      {
	//$ move outside of loop
        // swap them
        swap = strings[i];
        strings[i] = strings[j];
        strings[j] = swap;
      }
    }
  }
}

/*
 * Reads num strings from the file and stores them into an array of C
 * style strings.  If the open file contains fewer than num strings,
 * prints an error message and exits.  If the open file contains more
 * than num strings, reads in the first num strings in the file.
 * Returns the array with the stored strings.
 */
char **readFile(FILE *input, int num)
{
  // array of strings with num elements
  char **array;
  // dynamically allocate memory for the array of strings
  array = (char **)malloc(num * sizeof(char *));
  // array for storing one string
  char word[stringLength];
  // counter for the number of strings in the file
  int i = 0;
  // read in each string
  while ((i < num) && (!feof(input)))
  {
    // check if string was read
    if (fscanf(input, "%s", word) > 0)
    {
      // dynamically allocate the number of byte need to store the string
      array[i] = (char *)malloc((1 + strlen(word)) * sizeof(char));
      strcpy(array[i], word);
      i++;
    }
  }
  if (i < num)
  {
    printf("number of strings in the file less than specified number! \n");
    exit(1);
  }
  return array;
}

/*
 * Asks the user to enter a filename and number of strings to read
 * from the file via stdin.  Prints unsorted strings in the order they
 * were read in to stdout.  Then sorts strings before printing the
 * sorted strings to stdout.
 */
int main(int argc, char **argv)
{
  // file name string
  char file[fileLength];
  printf("Please enter a filename: \n");
  // read in filename
  // int to check if it actually read in something
  int temp;
  temp = scanf("%s", file);
  if (!temp)
  {
    printf("you did not enter a filename! \n");
    exit(1);
  }
  // number of strings to read in
  int numStrings;
  printf("Please enter the number of strings to read: \n");
  scanf("%d", &numStrings);
  if (!numStrings)
  {
    printf("you did not enter a valid number! \n");
    exit(1);
  }
  if (numStrings < 1)
  {
    printf("number invalid! \n");
    exit(1);
  }
  // file to be read
  FILE *newFile = fopen(file, "r");
  if (!newFile)
  {
    printf("filename invalid! \n");
    exit(1);
  }
  // strings read from the file
  char **fileArray;
  fileArray = readFile(newFile, numStrings);
  printf("Before: \n");
  printStrings(fileArray, numStrings);
  sortStrings(fileArray, numStrings);
  printf("After: \n");
  printStrings(fileArray, numStrings);
  freeStrings(fileArray, numStrings);
  fclose(newFile);
  return 0;
}
