#include <stdio.h>
#include <stdlib.h>

/*
 * Given an array containing size elements, prints those items to
 * stdout, with single spaces between each element.
 */
void printArray(int *array, int size)
{
  // print the array
  for (int i = 0; i < size; i++)
  {
    printf("%d ", array[i]);
  }
  printf("\n");
}

/*
 * Given an int array containing size elements, sorts those elements
 * in place using selection sort.
 */
void sortArray(int *array, int size)
{
  // set a variable for the new smallest int to be swapped
  int swap;
  for (int i = 0; i < size; i++)
  {
    for (int j = i + 1; j < size; j++)
    {
      // if a new smaller int is found
      if (array[j] < array[i])
      {

	//$ this should be outside of inner loop
        // swap them
        swap = array[i];
        array[i] = array[j];
        array[j] = swap;
      }
    }
  }
}

/*
 * Requests a positive number from the user via stdin.  Randomly
 * generates that number of ints in the range [0,100).  Prints those
 * numbers before sorting them and prints them again in sorted order.
 */
int main(int argc, char **argv)
{
  int pos;
  printf("Please enter a positive integer: \n");
  // read in pos
  //$ should check to see if scanf returns 1
  scanf("%d", &pos);
  // check if pos is a positive integer
  if (pos <= 0)
  {
    printf("you did not enter a positive integer! \n");
    exit(1);
  }
  // initialize array and dynamically allocate memory for the array
  int *array;
  array = (int *)malloc(pos * sizeof(int));
  // fill the array
  for (int i = 0; i < pos; i++)
  {
    array[i] = rand() % 100;
  }
  printf("Before: \n");
  printArray(array, pos);
  sortArray(array, pos);
  printf("After: \n");
  printArray(array, pos);
  free(array);
  return 0;
}
