# CS237 Lab 3 Feedback
Total score on this lab:  74.5/75

## Practice with `malloc` Feedback

### `sortInts.c`
* `main`:  2.75/3
* `printArray`:  1/1
* `sortArray`: 1.75/2
- scanf should check for a return value of 1
- the swapping should happen outside of loop in sortArray

### `readFile.c`
* `main`:  2/2
* `readFile`: 3/3
* `sortStrings`: 2/2
* `printStrings`: 1/1
* `freeStrings`: 2/2

#### Makefile:  2/2
#### style points:  2/2

## GDBomb Lab Feedback
We looked at the bomb you were assigned and
used the answers provided in your defuser.txt
file to determine your score according to the
lab specifications:
  * Each of the first four phases was worth 10 points, 
    and the fifth phase was worth 15, for a total of 55 points.

We also awarded extra credit for completing phases 6 and/or 7.
(Extra credit is calculated separately from your lab grade,
and applied at the end of the semester.)

### GDBomb Score
Your bomb number was: ["93"]
  * 55 / 55 , with  1 extra credit phases defused.
